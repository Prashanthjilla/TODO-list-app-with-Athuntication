const images1=['https://upload.wikimedia.org/wikipedia/commons/3/35/Neckertal_20150527-6384.jpg'
,'https://llandscapes-10674.kxcdn.com/wp-content/uploads/2019/07/lighting.jpg'
,'https://www.slrlounge.com/wp-content/uploads/2020/06/best-landscape-photographers-to-follow-in-2020.jpg'
,'https://media-exp1.licdn.com/dms/image/C561BAQGEbvT3SFyR9Q/company-background_10000/0/1582050035728?e=2159024400&v=beta&t=xwPLRsVBBNXQQS3HN3q7hsYXmt6JxJsH6lpnbh9Y1ko'
,'https://www.tom-archer.com/wp-content/uploads/2018/06/milford-sound-night-fine-art-photography-new-zealand.jpg'
,'https://img.freepik.com/free-vector/spring-landscape-scene_23-2148849832.jpg?size=626&ext=jpg&ga=GA1.2.926046015.1621555200'
,'https://www.mickeyshannon.com/images/landscape-photography.jpg'
,'https://img.freepik.com/free-vector/nature-scene-with-river-hills-forest-mountain-landscape-flat-cartoon-style-illustration_1150-37326.jpg?size=626&ext=jpg']

export default images1;
