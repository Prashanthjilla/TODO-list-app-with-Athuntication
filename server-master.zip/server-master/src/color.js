const colors = [
  '#0a1d37','#5e454b','#e5d549','#eba83a',"#F6EA41",'#F048C6','#9600FF','#AEBAF8','#EEBD89','#D13ABD','#0CCDA3','#CF1CD3','F9957F','9618F7'
]

export default colors;
